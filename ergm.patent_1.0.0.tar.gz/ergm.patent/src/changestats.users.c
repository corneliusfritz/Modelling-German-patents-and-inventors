/*  File src/changestats.users.c in package ergm.userterms, part of the Statnet suite
 *  of packages for network analysis, https://statnet.org .
 *
 *  This software is distributed under the GPL-3 license.  It is free,
 *  open source, and has the attribution requirements (GPL Section 7) at
 *  https://statnet.org/attribution
 *
 *  Copyright 2012-2019 Statnet Commons
 */
#include "changestats.users.h"

CHANGESTAT_FN(d_two_star_log1p) {
  Vertex t, h, v;
  int i, ind,tmp_change;
  Edge e;
  double res;
  ZERO_ALL_CHANGESTATS(i);
  FOR_EACH_TOGGLE(i) {
    t = TAIL(i); h = HEAD(i);
    tmp_change = 0;
    STEP_THROUGH_INEDGES(h, e, v){
      ind = t + (v-1)*INPUT_PARAM[0];
      /* (h-1)*INPUT_PARAM[0] + v */
      tmp_change += INPUT_PARAM[ind];
    }
    // if(IS_UNDIRECTED_EDGE(t,h)){
    //   ind = t + (v-1)*INPUT_PARAM[0];
    //   /* (h-1)*INPUT_PARAM[0] + v */
    //   tmp_change += INPUT_PARAM[ind];
    // }

    tmp_change =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change : tmp_change;
    res = log(abs(tmp_change) + 1.00);
    CHANGE_STAT[0] =IS_UNDIRECTED_EDGE(t,h) ? - res : res;
    TOGGLE_IF_MORE_TO_COME(i);
  }
  UNDO_PREVIOUS_TOGGLES(i);
}


CHANGESTAT_FN(d_two_star_alt) {
  Vertex t, h, v;
  int i, tmp_change,ind;
  Edge e;
  ZERO_ALL_CHANGESTATS(i);
  FOR_EACH_TOGGLE(i) {
    t = TAIL(i); h = HEAD(i);
    tmp_change = 0;
    STEP_THROUGH_INEDGES(h, e, v){
      ind = t + (v-1)*INPUT_PARAM[0];
      /* (h-1)*INPUT_PARAM[0] + v */
      tmp_change += INPUT_PARAM[ind];
    }
    // if(IS_UNDIRECTED_EDGE(t,h)){
    //   ind = t + (v-1)*INPUT_PARAM[0];
    //   /* (h-1)*INPUT_PARAM[0] + v */
    //   tmp_change += INPUT_PARAM[ind];
    // }
    CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change : tmp_change;
    TOGGLE_IF_MORE_TO_COME(i);
    }
  UNDO_PREVIOUS_TOGGLES(i);
}


CHANGESTAT_FN(d_two_star_avr) {
  Vertex t, h, v, n;
  int i,ind;
  Edge e;
  double tmp_change;
  ZERO_ALL_CHANGESTATS(i);
  FOR_EACH_TOGGLE(i) {
    t = TAIL(i); h = HEAD(i);
    tmp_change = n = 0;
    STEP_THROUGH_INEDGES(h, e, v){
      ind = t + (v-1)*INPUT_PARAM[0];
      /* (h-1)*INPUT_PARAM[0] + v */
      tmp_change += INPUT_PARAM[ind];
      n += 1;
    }
    // if(IS_UNDIRECTED_EDGE(t,h)){
    //   ind = t + (v-1)*INPUT_PARAM[0];
    //   /* (h-1)*INPUT_PARAM[0] + v */
    //   tmp_change += INPUT_PARAM[ind];
    // }
    CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change/(n-1)*100 : tmp_change/n*100;
    // CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change : tmp_change;
    TOGGLE_IF_MORE_TO_COME(i);
  }
  UNDO_PREVIOUS_TOGGLES(i);
}

CHANGESTAT_FN(d_b1_two_star_avr) {
  Vertex t, h;
  int i,ind, n;
  Edge e;
  float v;
  ZERO_ALL_CHANGESTATS(i);
  FOR_EACH_TOGGLE(i) {
    t = TAIL(i); h = HEAD(i);
    v = OUT_DEG[t];
    n = INPUT_PARAM[0];
    CHANGE_STAT[0] = IS_UNDIRECTED_EDGE(t,h) ? - (v-1)/n : v/n;
    // CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - (v-1)/n : v/n;
    // CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change : tmp_change;
    TOGGLE_IF_MORE_TO_COME(i);
  }
  UNDO_PREVIOUS_TOGGLES(i);
}

CHANGESTAT_FN(d_b2_two_star_avr) {
  Vertex t, h;
  int i,ind, n;
  Edge e;
  float v;
  ZERO_ALL_CHANGESTATS(i);
  FOR_EACH_TOGGLE(i) {
    t = TAIL(i); h = HEAD(i);
    v = IN_DEG[h];
    n = INPUT_PARAM[0];
    CHANGE_STAT[0] = IS_UNDIRECTED_EDGE(t,h) ? - (v-1)/n : v/n;
    // CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - (v-1)/n : v/n;
    // CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change : tmp_change;
    TOGGLE_IF_MORE_TO_COME(i);
  }
  UNDO_PREVIOUS_TOGGLES(i);
}




CHANGESTAT_FN(d_two_star_indep) {
  Vertex t, h, v;
  int i,ind, n;
  Edge e;
  float tmp_change;
  ZERO_ALL_CHANGESTATS(i);
  FOR_EACH_TOGGLE(i) {
    t = TAIL(i); h = HEAD(i);
    tmp_change = n = 0;
    STEP_THROUGH_INEDGES(h, e, v){
      ind = t + (v-1)*INPUT_PARAM[0] + 1;
      /* (h-1)*INPUT_PARAM[0] + v */
      tmp_change += INPUT_PARAM[ind];
      n += 1;
    }
    // if(IS_UNDIRECTED_EDGE(t,h)){
    //   ind = t + (v-1)*INPUT_PARAM[0];
    //   /* (h-1)*INPUT_PARAM[0] + v */
    //   tmp_change += INPUT_PARAM[ind];
    // }
    CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change/((n-1)*INPUT_PARAM[0]*INPUT_PARAM[1]) : tmp_change/(n*INPUT_PARAM[0]*INPUT_PARAM[1]);
    // CHANGE_STAT[0] =  IS_UNDIRECTED_EDGE(t,h) ? - tmp_change : tmp_change;
    TOGGLE_IF_MORE_TO_COME(i);
  }
  UNDO_PREVIOUS_TOGGLES(i);
}
