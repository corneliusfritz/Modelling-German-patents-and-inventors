
#' Log1p transformed pairwise statistics
#'
#' @name two_star_log1p
#'
#'
InitErgmTerm.two_star_log1p <- function(nw, arglist, ...) {
  a <- check.ErgmTerm(nw, arglist, directed=FALSE, bipartite=TRUE,
                      varnames = c("actor_matrix", "label", "number_node_a"),
                      vartypes = c("matrix","character", "numeric"),
                      required = c(TRUE,TRUE,TRUE),
                      defaultvalues = list(NULL, NULL, NULL))
  list(name = "two_star_log1p",
       coef.names = a$label,
       pkgname = "ergm.patent",
       inputs = c(a$number_node_a, as.numeric(t(a$actor_matrix))),
       dependence = TRUE)
}

#' Average pairwise statistics
#'
#' The second argument specifies the actor matrix, the third the label , and the fourth the numbers of actors in actor set a
#' @name two_star_avr
#' @param nw network
#'
InitErgmTerm.two_star_avr <- function(nw, arglist, ...) {
  a <- check.ErgmTerm(nw, arglist, directed=FALSE, bipartite=TRUE,
                      varnames = c("actor_matrix", "label", "number_node_a"),
                      vartypes = c("matrix","character", "numeric"),
                      required = c(TRUE,TRUE,TRUE),
                      defaultvalues = list(NULL, NULL, NULL))
  list(name = "two_star_avr",
       coef.names = a$label,
       pkgname = "ergm.patent",
       inputs = c(a$number_node_a, as.numeric(t(a$actor_matrix))),
       dependence = TRUE)
}

#' Average pairwise statistics
#'
#' The second argument specifies the label , and the third the numbers of actors in actor set a
#' @name two_star_avr
#' @param nw network
#'
InitErgmTerm.b1_two_star_avr <- function(nw, arglist, ...) {
  a <- check.ErgmTerm(nw, arglist, directed=FALSE, bipartite=TRUE,
                      varnames = c("label", "number_node_b"),
                      vartypes = c("character", "numeric"),
                      required = c(TRUE,TRUE),
                      defaultvalues = list(NULL, NULL))
  list(name = "b1_two_star_avr",
       coef.names = a$label,
       pkgname = "ergm.patent",
       inputs = c(a$number_node_b),
       dependence = TRUE)
}


InitErgmTerm.b2_two_star_avr <- function(nw, arglist, ...) {
  a <- check.ErgmTerm(nw, arglist, directed=FALSE, bipartite=TRUE,
                      varnames = c("label", "number_node_a"),
                      vartypes = c("character", "numeric"),
                      required = c(TRUE,TRUE),
                      defaultvalues = list(NULL, NULL))
  list(name = "b1_two_star_avr",
       coef.names = a$label,
       pkgname = "ergm.patent",
       inputs = c(a$number_node_a),
       dependence = TRUE)
}

InitErgmTerm.two_star_indep <- function(nw, arglist, ...) {
  a <- check.ErgmTerm(nw, arglist, directed=FALSE, bipartite=TRUE,
                      varnames = c("actor_matrix", "label", "number_node_a","number_node_b"),
                      vartypes = c("matrix","character", "numeric", "numeric"),
                      required = c(TRUE,TRUE,TRUE,TRUE),
                      defaultvalues = list(NULL, NULL, NULL, NULL))
  list(name = "two_star_indep",
       coef.names = a$label,
       pkgname = "ergm.patent",
       inputs = c(a$number_node_a, a$number_node_b, as.numeric(t(a$actor_matrix))),
       dependence = TRUE)
}
